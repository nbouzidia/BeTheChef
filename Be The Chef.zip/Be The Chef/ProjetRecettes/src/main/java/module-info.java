module com.example.projetrecettes {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;


    opens Presentation to javafx.fxml;
    exports Presentation;
}