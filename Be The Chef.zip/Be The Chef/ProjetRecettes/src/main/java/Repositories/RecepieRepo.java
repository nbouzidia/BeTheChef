package Repositories;

import models.Nutrition;
import org.w3c.dom.*;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.*;

import models.Ingredient;
import models.Recipe;

public class RecepieRepo {
    private List<Recipe> recipes;

    public RecepieRepo() {
        this.recipes = new ArrayList<>();
    }

    public List<Recipe> getRecipes() {
        return recipes;
    }

    public void setRecipes(List<Recipe> recipes) {
        this.recipes = recipes;
    }

    public void init(String filePath) {
        try {
            File xmlFile = new File(filePath);

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);

            doc.getDocumentElement().normalize();

            NodeList recipeNodes = doc.getElementsByTagName("rcp:recipe");

            for (int i = 0; i < recipeNodes.getLength(); i++) {
                Node recipeNode = recipeNodes.item(i);

                if (recipeNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element recipeElement = (Element) recipeNode;
                    Recipe recipe = parseRecipe(recipeElement);
                    recipes.add(recipe);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Recipe parseRecipe(Element recipeElement) {
        String id = recipeElement.getAttribute("id");
        String title = getTextContent(recipeElement, "rcp:title");
        String date = getTextContent(recipeElement, "rcp:date");
        List<Ingredient> ingredients = parseIngredients(recipeElement.getElementsByTagName("rcp:ingredient"));
        List<String> preparationSteps = parsePreparationSteps(recipeElement.getElementsByTagName("rcp:step"));
        String comment = getTextContent(recipeElement, "rcp:comment");
        Nutrition nutrition = parseNutrition(recipeElement.getElementsByTagName("rcp:nutrition"));
        String relatedRecipeId = getTextContent(recipeElement, "rcp:related");
        String relatedRecipeDescription = "";

        Recipe recipe = new Recipe(id, title, date, ingredients, preparationSteps, comment, nutrition, Collections.singletonList(relatedRecipeId));

        System.out.println(recipe.getId());

        return recipe;
    }

    private List<Ingredient> parseIngredients(NodeList ingredientNodes) {
        List<Ingredient> ingredients = new ArrayList<>();
        for (int i = 0; i < ingredientNodes.getLength(); i++) {
            Element ingredientElement = (Element) ingredientNodes.item(i);
            String name = ingredientElement.getAttribute("name");
            String amountStr = ingredientElement.getAttribute("amount");
            int amount = 0;
            if (!amountStr.isEmpty()) {
                try {
                    amount = Integer.parseInt(amountStr);
                } catch (NumberFormatException e) {
                    amount = 0;
                }
            }
            String unit = ingredientElement.getAttribute("unit"); // Ajout de cette ligne
            Ingredient ingredient = new Ingredient(name, amount, unit);
            ingredients.add(ingredient);
        }
        return ingredients;
    }


    private List<String> parsePreparationSteps(NodeList preparationNodes) {
        List<String> preparationSteps = new ArrayList<>();
        for (int i = 0; i < preparationNodes.getLength(); i++) {
            Element preparationElement = (Element) preparationNodes.item(i);
            String preparationStep = preparationElement.getTextContent().trim();
            if (!preparationStep.isEmpty()) {
                preparationSteps.add(preparationStep);
            }
        }
        return preparationSteps;
    }

    private Nutrition parseNutrition(NodeList nutritionNodes) {
        Nutrition nutrition = new Nutrition();
        if (nutritionNodes.getLength() > 0) {
            Element nutritionElement = (Element) nutritionNodes.item(0);
            int calories = Integer.parseInt(nutritionElement.getAttribute("calories"));
            String fat = nutritionElement.getAttribute("fat");
            String carbohydrates = nutritionElement.getAttribute("carbohydrates");
            String protein = nutritionElement.getAttribute("protein");
            String alcohol = nutritionElement.getAttribute("alcohol");

            nutrition.setCalories(calories);
            nutrition.setFat(fat);
            nutrition.setCarbohydrates(carbohydrates);
            nutrition.setProtein(protein);
            nutrition.setAlcohol(alcohol);
        }
        return nutrition;
    }

    private String getTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0 && nodeList.item(0).hasChildNodes()) {
            return nodeList.item(0).getChildNodes().item(0).getNodeValue();
        } else {
            return "";
        }
    }

    public List<String> listRecipeTitles() {
        recipes.stream()
                .map(Recipe::getTitle)
                .forEach(title -> System.out.println("Recipe Title: " + title));
        return null;
    }
    public List<String> getRecipeTitle() {
        return recipes.stream()
                .map(Recipe::getTitle)
                .collect(Collectors.toList());
    }
    public Recipe findRecipeByTitle(String title) {
        for (Recipe recipe : recipes) {
            if (recipe.getTitle().equalsIgnoreCase(title)) {
                return recipe;
            }
        }
        return null;
    }


    public int getTotalEggsUsed() {
        return recipes.stream()
                .flatMap(recipe -> recipe.getIngredients().stream())
                .filter(ingredient -> ingredient.getName().toLowerCase().contains("egg"))
                .mapToInt(Ingredient::getAmount)
                .sum();
    }

    public List<Recipe> getRecipesWithOliveOil() {
        return recipes.stream()
                .filter(recipe -> recipe.getIngredients().stream()
                        .anyMatch(ingredient -> ingredient.getName().equalsIgnoreCase("olive oil")))
                .collect(Collectors.toList());
    }

    public Map<Recipe, Integer> calculateEggsPerRecipe() {
        Map<Recipe, Integer> eggsPerRecipe = new HashMap<>();
        for (Recipe recipe : recipes) {
            int eggCount = 0;
            for (Ingredient ingredient : recipe.getIngredients()) {
                if (ingredient.getName().toLowerCase().contains("egg")) {
                    eggCount += ingredient.getAmount();
                }
            }
            eggsPerRecipe.put(recipe, eggCount);
        }
        return eggsPerRecipe;
    }
    public List<Recipe> getRecipesUnder500Calories() {
        return recipes.stream()
                .filter(recipe -> recipe.getNutrition().getCalories() < 500)
                .collect(Collectors.toList());
    }
    public double getSugarQuantityForZuppaInglese() {
        for (Recipe recipe : recipes) {
            if (recipe.getTitle().equals("Zuppa Inglese")) {
                for (Ingredient ingredient : recipe.getIngredients()) {
                    if (ingredient.getName().toLowerCase().contains("sugar")) {
                        return ingredient.getAmount();
                    }
                }
            }
        }
        return 0.0; // Retourne 0.0 si la recette "Zuppa Inglese" n'est pas trouvée ou si aucune quantité de sucre n'est spécifiée
    }
    public void displayFirstTwoStepsOfZuppaInglese() {
        for (Recipe recipe : recipes) {
            if (recipe.getTitle().equals("Zuppa Inglese")) {
                List<String> preparationSteps = recipe.getPreparationSteps();
                if (preparationSteps.size() >= 2) {
                    System.out.println("Étape 1 : " + preparationSteps.get(0));
                    System.out.println("Étape 2 : " + preparationSteps.get(1));
                } else if (preparationSteps.size() == 1) {
                    System.out.println("Étape unique : " + preparationSteps.get(0));
                } else {
                    System.out.println("Aucune étape trouvée pour la recette Zuppa Inglese");
                }
                return;
            }
        }
        System.out.println("Recette Zuppa Inglese introuvable");
    }
    public List<String> listFirstTwoStepsOfZuppaInglese() {
        return recipes.stream()
                .filter(recipe -> recipe.getTitle().equals("Zuppa Inglese"))
                .findFirst()
                .map(recipe -> {
                    List<String> preparationSteps = recipe.getPreparationSteps();
                    if (preparationSteps.size() >= 2) {
                        return preparationSteps.subList(0, 2)
                                .stream()
                                .map(step -> "Étape : " + step)
                                .collect(Collectors.toList());
                    } else if (!preparationSteps.isEmpty()) {
                        return List.of("Étape unique : " + preparationSteps.get(0));
                    } else {
                        return List.of("Aucune étape trouvée pour la recette Zuppa Inglese");
                    }
                })
                .orElse(List.of("Recette Zuppa Inglese introuvable"));
    }
    public List<Recipe> getRecipesWithMoreThanFiveSteps() {
        List<Recipe> recipesWithMoreThanFiveSteps = new ArrayList<>();
        for (Recipe recipe : recipes) {
            if (recipe.getPreparationSteps().size() > 5) {
                recipesWithMoreThanFiveSteps.add(recipe);
            }
        }
        return recipesWithMoreThanFiveSteps;
    }
    public List<Recipe> getRecipesWithoutButter() {
        return recipes.stream()
                .filter(recipe -> recipe.getIngredients().stream()
                        .noneMatch(ingredient -> ingredient.getName().equalsIgnoreCase("butter")))
                .collect(Collectors.toList());
    }
    public List<Recipe> getRecipesWithCommonIngredients() {
        Recipe zuppaInglese = recipes.stream()
                .filter(recipe -> recipe.getTitle().equals("Zuppa Inglese"))
                .findFirst()
                .orElse(null);

        if (zuppaInglese == null) {
            return List.of(); // Retourne une liste vide si Zuppa Inglese n'est pas trouvée
        }

        Set<String> ingredientsZuppaInglese = zuppaInglese.getIngredients().stream()
                .map(Ingredient::getName)
                .map(String::toLowerCase)
                .collect(Collectors.toSet());

        return recipes.stream()
                .filter(recipe -> !recipe.equals(zuppaInglese))
                .filter(recipe -> recipe.getIngredients().stream()
                        .map(Ingredient::getName)
                        .map(String::toLowerCase)
                        .anyMatch(ingredientsZuppaInglese::contains))
                .collect(Collectors.toList());
    }
    public Recipe getMostCaloricRecipe() {
        if (recipes.isEmpty()) {
            return null; // Retourne null si la liste des recettes est vide
        }

        Recipe mostCaloricRecipe = recipes.get(0); // Supposons que la première recette est la plus calorique pour le moment
        int maxCalories = mostCaloricRecipe.getNutrition().getCalories();

        for (Recipe recipe : recipes) {
            int calories = recipe.getNutrition().getCalories();
            if (calories > maxCalories) {
                maxCalories = calories;
                mostCaloricRecipe = recipe;
            }
        }

        return mostCaloricRecipe;
    }
    // l'unité la plus fréquente
    public String unitePlusFrequente() {
        Map<String, Long> uniteCounts = recipes.stream()
                .flatMap(recipe -> recipe.getIngredients().stream())
                .map(Ingredient::getUnit)
                .filter(unit -> unit != null && !unit.isEmpty()) // Exclure les chaînes vides

                .collect(Collectors.groupingBy(unit -> unit, Collectors.counting()));

        return uniteCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("Aucune unité trouvée");
    }

    public int countIngredientsPerRecipe(Recipe recipe) {
        return recipe.getIngredients().size();
    }
    public Map<Recipe, Integer> calculateIngredientCountPerRecipe() {
        Map<Recipe, Integer> ingredientCountPerRecipe = new HashMap<>();
        for (Recipe recipe : recipes) {
            int ingredientCount = recipe.getIngredients().size();
            ingredientCountPerRecipe.put(recipe, ingredientCount);
        }
        return ingredientCountPerRecipe;
    }
    private double extractFatValue(String fat) {
        if (fat == null || fat.isEmpty()) {
            return 0.0; // Retourner 0 si la chaîne est vide ou nulle
        }

        // Supprimer le symbole de pourcentage (%) et convertir en double
        try {
            return Double.parseDouble(fat.replace("%", ""));
        } catch (NumberFormatException e) {
            // En cas d'erreur de conversion, retourner 0.0
            return 0.0;
        }
    }

    public Recipe getRecipeWithMostFat() {
        Recipe recipeWithMostFat = null;
        double maxFat = Double.MIN_VALUE; // Initialiser à la valeur minimale possible

        for (Recipe recipe : recipes) {
            double fatValue = extractFatValue(recipe.getNutrition().getFat()); // Utiliser la méthode extractFatValue
            if (fatValue > maxFat) {
                maxFat = fatValue;
                recipeWithMostFat = recipe;
            }
        }

        return recipeWithMostFat;
    }

    public String mostUsedIngredient() {
        Map<String, Integer> ingredientCounts = new HashMap<>();

        // Parcourir toutes les recettes
        for (Recipe recipe : recipes) {
            // Parcourir tous les ingrédients de la recette
            for (Ingredient ingredient : recipe.getIngredients()) {
                // Mettre à jour le compteur d'occurrences de l'ingrédient dans la Map
                ingredientCounts.put(ingredient.getName(), ingredientCounts.getOrDefault(ingredient.getName(), 0) + 1);
            }
        }

        // Trouver l'ingrédient avec le nombre d'occurrences le plus élevé dans la Map
        String mostUsedIngredient = "";
        int maxOccurrences = 0;
        for (Map.Entry<String, Integer> entry : ingredientCounts.entrySet()) {
            if (entry.getValue() > maxOccurrences) {
                mostUsedIngredient = entry.getKey();
                maxOccurrences = entry.getValue();
            }
        }

        return mostUsedIngredient;
    }
    public List<Recipe> displayRecipesSortedByIngredientCount() {
        // Trier la liste des recettes en utilisant un comparateur basé sur le nombre d'ingrédients
        List<Recipe> liste = new ArrayList<>();
        recipes.sort(Comparator.comparingInt(recipe -> recipe.getIngredients().size()));


        // Afficher les recettes triées
        for (Recipe recipe : recipes) {
            liste.add(recipe);
        }
        return liste;

    }
    public void displayRecipesByIngredient() {
        // Créer une map pour stocker les recettes associées à chaque ingrédient
        Map<String, List<Recipe>> recipesByIngredient = new HashMap<>();

        // Parcourir toutes les recettes
        for (Recipe recipe : recipes) {
            // Parcourir tous les ingrédients de la recette
            for (Ingredient ingredient : recipe.getIngredients()) {
                // Récupérer la liste des recettes associées à l'ingrédient actuel
                List<Recipe> recipesForIngredient = recipesByIngredient.getOrDefault(ingredient.getName(), new ArrayList<>());
                // Ajouter la recette actuelle à la liste des recettes associées à l'ingrédient
                recipesForIngredient.add(recipe);
                // Mettre à jour la map avec la nouvelle liste de recettes
                recipesByIngredient.put(ingredient.getName(), recipesForIngredient);
            }
        }


        // Afficher les recettes associées à chaque ingrédient
        for (Map.Entry<String, List<Recipe>> entry : recipesByIngredient.entrySet()) {
            String ingredient = entry.getKey();
            List<Recipe> recipes = entry.getValue();
            System.out.println("Recettes utilisant l'ingrédient \"" + ingredient + "\" :");
            for (Recipe recipe : recipes) {
                System.out.println("- " + recipe.getTitle());
            }
            System.out.println();
        }
    }
    public Map<String, List<Recipe>> listRecipesByIngredient() {
        // Créer une map pour stocker les recettes associées à chaque ingrédient
        Map<String, List<Recipe>> recipesByIngredient = new HashMap<>();

        // Parcourir toutes les recettes
        for (Recipe recipe : recipes) {
            // Parcourir tous les ingrédients de la recette
            for (Ingredient ingredient : recipe.getIngredients()) {
                // Récupérer la liste des recettes associées à l'ingrédient actuel
                List<Recipe> recipesForIngredient = recipesByIngredient.getOrDefault(ingredient.getName(), new ArrayList<>());
                // Ajouter la recette actuelle à la liste des recettes associées à l'ingrédient
                recipesForIngredient.add(recipe);
                // Mettre à jour la map avec la nouvelle liste de recettes
                recipesByIngredient.put(ingredient.getName(), recipesForIngredient);
            }
        }
        return recipesByIngredient;
    }

    public Map<String, Integer> calculateRecipesByPreparationStep() {
        // Créer une map pour stocker le nombre de recettes par étape de réalisation
        Map<String, Integer> recipesByPreparationStep = new HashMap<>();

        // Parcourir toutes les recettes
        for (Recipe recipe : recipes) {
            // Parcourir toutes les étapes de réalisation de la recette
            for (String step : recipe.getPreparationSteps()) {
                // Mettre à jour la map avec l'étape actuelle
                recipesByPreparationStep.put(step, recipesByPreparationStep.getOrDefault(step, 0) + 1);
            }
        }

        return recipesByPreparationStep;
    }
    public Recipe findEasiestRecipe() {
        Recipe easiestRecipe = null;
        int minSteps = Integer.MAX_VALUE;

        // Parcourir toutes les recettes
        for (Recipe recipe : recipes) {
            // Vérifier si le nombre d'étapes de la recette actuelle est inférieur au minimum actuel
            if (recipe.getPreparationSteps().size() < minSteps) {
                minSteps = recipe.getPreparationSteps().size();
                easiestRecipe = recipe;
            }
        }
        return easiestRecipe;
    }

    }



