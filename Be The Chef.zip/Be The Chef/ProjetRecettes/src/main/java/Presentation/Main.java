package Presentation;

import Repositories.RecepieRepo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import models.Recipe;

public class Main {
    public static void main(String[] args) {
        RecepieRepo recipeRepo = new RecepieRepo();
        recipeRepo.init("C:\\Users\\nassim\\ProjetRecettes\\src\\main\\resources\\Presentation\\recipes.xml");

        // Afficher les titres des recettes
        System.out.println("Titres des recettes :");

        System.out.println();

        // Calculer le nombre total d'œufs utilisés
        int totalEggs = recipeRepo.getTotalEggsUsed();
        System.out.println("Nombre total d'œufs utilisés : " + totalEggs);
        System.out.println();

        // Retourner les recettes utilisant l'huile d'olive
        List<Recipe> recipesWithOliveOil = recipeRepo.getRecipesWithOliveOil();
        System.out.println("Recettes utilisant de l'huile d'olive :");
        for (Recipe recipe : recipesWithOliveOil) {
            System.out.println(recipe.getTitle());
        }
        System.out.println();

        // Calculer le nombre d'œufs par recette
        Map<Recipe, Integer> eggsPerRecipe = recipeRepo.calculateEggsPerRecipe();
        System.out.println("Nombre d'œufs par recette :");
        for (Map.Entry<Recipe, Integer> entry : eggsPerRecipe.entrySet()) {
            Recipe recipe = entry.getKey();
            int eggCount = entry.getValue();
            System.out.println(recipe.getTitle() + " : " + eggCount);
        }

        //Recettes fournissant moins de 500 calories
        List<Recipe> recipesUnder500Calories = recipeRepo.getRecipesUnder500Calories();
        System.out.println("Recettes fournissant moins de 500 calories :");
        for (Recipe recipe : recipesUnder500Calories) {
            System.out.println(recipe.getTitle() + " - " + recipe.getNutrition().getCalories() + " calories");
        }

        //quantite de sucre

        double sugarQuantity = recipeRepo.getSugarQuantityForZuppaInglese();
        System.out.println("Quantité de sucre utilisée dans la recette Zuppa Inglese : " + sugarQuantity);
        // plus de 5 etapes
        recipeRepo.displayFirstTwoStepsOfZuppaInglese();
        List<Recipe> recipesWithMoreThanFiveSteps = recipeRepo.getRecipesWithMoreThanFiveSteps();
        System.out.println("Recettes avec plus de 5 étapes :");
        for (Recipe recipe : recipesWithMoreThanFiveSteps) {
            System.out.println(recipe.getTitle());
        }
        // recettes sans beuurre
        List<Recipe> recipesWithoutButter = recipeRepo.getRecipesWithoutButter();
        System.out.println("Recettes sans beurre :");
        for (Recipe recipe : recipesWithoutButter) {
            System.out.println(recipe.getTitle());


        }
        Recipe zuppaInglese = recipeRepo.findRecipeByTitle("Zuppa Inglese");
        //List<Recipe> recipesWithCommonIngredients = recipeRepo.getRecipesWithCommonIngredients(zuppaInglese);

        /*System.out.println("Recettes avec des ingrédients en commun avec Zuppa Inglese :");
        for (Recipe recipe : recipesWithCommonIngredients) {
            System.out.println(recipe.getTitle());
        }*/

   // la recette la plus calorique
        Recipe mostCaloricRecipe = recipeRepo.getMostCaloricRecipe();
        if (mostCaloricRecipe != null) {
            System.out.println("Recette la plus calorique :");
            System.out.println(mostCaloricRecipe.getTitle());
        } else {
            System.out.println("Aucune recette n'a été trouvée.");
        }
// unité la plus frequente
        String mostFrequentUnit = recipeRepo.unitePlusFrequente();
        System.out.println("L'unité la plus fréquente est : " + mostFrequentUnit);
        //***********************
// Calculer le nombre d'ingrédients par recette
        System.out.println("Nombre d'ingrédients par recette :");
        for (Recipe recipe : recipeRepo.getRecipes()) {
            int ingredientCount = recipeRepo.countIngredientsPerRecipe(recipe);
            System.out.println(recipe.getTitle() + " : " + ingredientCount);
        }
        //recette plus de graisse

        // Tester la méthode getRecipeWithMostFat()
        Recipe recipeWithMostFat = recipeRepo.getRecipeWithMostFat();
        if (recipeWithMostFat != null) {
            System.out.println("Recette avec le plus de graisses : " + recipeWithMostFat.getTitle());
            System.out.println("Quantité de graisses : " + recipeWithMostFat.getNutrition().getFat());
        } else {
            System.out.println("Aucune recette n'a été trouvée.");
        }

        // Tester la méthode mostUsedIngredient()
        String mostUsedIngredient = recipeRepo.mostUsedIngredient();
        System.out.println("Ingrédient le plus utilisé : " + mostUsedIngredient);
        // tri

        System.out.println("Recettes triées par nombre d'ingrédients :");
        //recipeRepo.displayRecipesSortedByIngredientCount();

        //
        // Afficher les recettes associées à chaque ingrédient
        System.out.println("Recettes par ingrédient :");
        recipeRepo.displayRecipesByIngredient();

        Map<String, Integer> recipesByPreparationStep = recipeRepo.calculateRecipesByPreparationStep();

// Afficher la répartition des recettes par étape de réalisation
        System.out.println("Répartition des recettes par étape de réalisation :");
        for (Map.Entry<String, Integer> entry : recipesByPreparationStep.entrySet()) {
            String step = entry.getKey();
            int recipeCount = entry.getValue();
            System.out.println(step + " : " + recipeCount + " recettes");
        }
        Recipe easiestRecipe = recipeRepo.findEasiestRecipe();
         System.out.println("Recette la plus facile : " + easiestRecipe.getTitle());






    }
}
