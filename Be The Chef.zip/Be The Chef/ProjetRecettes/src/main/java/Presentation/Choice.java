package Presentation;

public class Choice {
}
