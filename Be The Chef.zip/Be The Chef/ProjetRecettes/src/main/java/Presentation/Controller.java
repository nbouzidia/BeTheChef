package Presentation;

import Repositories.RecepieRepo;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.Recipe;
import javafx.fxml.FXML;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Controller {

    @FXML
    private ChoiceBox<String> questionsBox;

    @FXML
    private TextArea resultLabel;

    private RecepieRepo recipeRepo;

    // Chemin du fichier de recettes


    @FXML
    public void initialize() {
        recipeRepo = new RecepieRepo();
        recipeRepo.init("C:\\Users\\nassim\\ProjetRecettes\\src\\main\\resources\\Presentation\\recipes.xml");

        // Initialiser les questions possibles dans le ChoiceBox
        List<String> questions = List.of(
                "Total des œufs utilisés",
                "Recettes utilisant de l'huile d'olive",
                "Liste des titres des recettes",
                "Œufs par recette",
                "Recettes avec moins de 500 calories",
                "Zuppa Inglese - Quantité de sucre",
                "Premières deux étapes de Zuppa Inglese",
                "Recettes avec plus de cinq étapes",
                "Recettes sans beurre",
                "Recettes avec des ingrédients communs à Zuppa Inglese",
                "Recette la plus calorique",
                "Unité la plus fréquente",
                "Nombre d'ingrédients par recette",
                "Recette avec le plus de matières grasses",
                "Ingrédient le plus utilisé",
                "Recettes triées par nombre d'ingrédients",
                "Recettes par ingrédient",
                "Recettes regroupées par nombre d'étapes",
                "Recette la plus facile"

        );
        questionsBox.getItems().addAll(questions);
    }

    @FXML
    public void onValidateQuestion() {
        String selectedQuestion = questionsBox.getValue();
        String result = "";

        // Appeler les méthodes correspondantes en fonction de la question sélectionnée
        switch (selectedQuestion) {
            case "Total des œufs utilisés":
                double totalEggsUsed = recipeRepo.getTotalEggsUsed();
                result = "Total des œufs utilisés : " + totalEggsUsed;
                break;
            case "Recettes utilisant de l'huile d'olive":
                List<Recipe> recipesWithOliveOil = recipeRepo.getRecipesWithOliveOil();
                result = "Recettes utilisant de l'huile d'olive :\n";
                for (Recipe recipe : recipesWithOliveOil) {
                    result += recipe.getTitle() + "\n"; // Ajoutez d'autres attributs de la recette si nécessaire
                }
                break;
            case "Liste des titres des recettes":
                List<String> recipeTitles = recipeRepo.getRecipeTitle();
                result = "Liste des titres des recettes :\n";
                for (String title : recipeTitles) {
                    result += title + "\n";
                }
                break;
            case "Œufs par recette":
                Map<Recipe, Integer> eggsCountPerRecipe = recipeRepo.calculateEggsPerRecipe();
                result = "Œufs par recette :\n";
                for (Map.Entry<Recipe, Integer> entry : eggsCountPerRecipe.entrySet()) {
                    Recipe recipe = entry.getKey();
                    int eggCount = entry.getValue();
                    result += recipe.getTitle() + " : " + eggCount + "\n";
                }
                break;

            case "Recettes avec moins de 500 calories":
                List<Recipe> recipesUnder500Calories = recipeRepo.getRecipesUnder500Calories();
                result = "Recettes avec moins de 500 calories :\n";
                for (Recipe recipe : recipesUnder500Calories) {
                    result += recipe.getTitle() + "\n";
                }
                break;
            case "Zuppa Inglese - Quantité de sucre":
                double zuppaIngleseSugar = recipeRepo.getSugarQuantityForZuppaInglese();
                result = "Zuppa Inglese - Quantité de sucre : " + zuppaIngleseSugar + " g\n";
                break;
            case "Premières deux étapes de Zuppa Inglese":
                List<String> firstTwoSteps = recipeRepo.listFirstTwoStepsOfZuppaInglese();
                result = "Premières deux étapes de Zuppa Inglese :\n";
                for (String step : firstTwoSteps) {
                    result += step + "\n";
                }
                break;

            case "Recettes avec plus de cinq étapes":
                List<Recipe> recipesWithMoreThanFiveSteps = recipeRepo.getRecipesWithMoreThanFiveSteps();
                result = "Recettes avec plus de cinq étapes :\n";
                for (Recipe recipe : recipesWithMoreThanFiveSteps) {
                    result += recipe.getTitle() + "\n";
                }
                break;
            case "Recettes sans beurre":
                List<Recipe> recipesWithoutButter = recipeRepo.getRecipesWithoutButter();
                result = "Recettes sans beurre :\n";
                for (Recipe recipe : recipesWithoutButter) {
                    result += recipe.getTitle() + "\n";
                }
                break;
            case "Recettes avec des ingrédients communs à Zuppa Inglese":
                List<Recipe> recipesWithCommonIngredientsWithZuppaInglese = recipeRepo.getRecipesWithCommonIngredients();
                result = "Recettes avec des ingrédients communs à Zuppa Inglese :\n";
                for (Recipe recipe : recipesWithCommonIngredientsWithZuppaInglese) {
                    result += recipe.getTitle() + "\n";
                }
                break;
            case "Recette la plus calorique":
                Recipe mostCaloricRecipe = recipeRepo.getMostCaloricRecipe();
                result = "Recette la plus calorique : " + mostCaloricRecipe.getTitle();
                break;
            case "Unité la plus fréquente":
                String mostFrequentUnit = recipeRepo.unitePlusFrequente();
                result = "Unité la plus fréquente : " + mostFrequentUnit;
                break;
            case "Nombre d'ingrédients par recette":
                result = "Nombre d'ingrédients par recette :\n";
                for (Recipe recipe : recipeRepo.getRecipes()) {
                    result += recipe.getTitle() + " : " + recipe.getIngredients().size() + "\n";
                }
                break;
            case "Recette avec le plus de matières grasses":
                Recipe recipeWithMostFat = recipeRepo.getRecipeWithMostFat();
                result = "Recette avec le plus de matières grasses : " + recipeWithMostFat.getTitle();
                break;
            case "Ingrédient le plus utilisé":
                String mostUsedIngredient = recipeRepo.mostUsedIngredient();
                result = "Ingrédient le plus utilisé : " + mostUsedIngredient;
                break;
            case "Recettes triées par nombre d'ingrédients":
                List<Recipe> recipesSortedByIngredientCount = recipeRepo.displayRecipesSortedByIngredientCount();
                result = "Recettes triées par nombre d'ingrédients :\n";
                for (Recipe recipe : recipesSortedByIngredientCount) {
                    result += recipe.getTitle() + "\n";
                }
                break;

            case "Recette la plus facile":
                Recipe easiestRecipe = recipeRepo.findEasiestRecipe();
                result = "Recette la plus facile : " + easiestRecipe.getTitle();
                break;

            case "Recettes par ingrédient":
                Map<String, List<Recipe>> recipesByIngredientMap = recipeRepo.listRecipesByIngredient();

                // Construire la chaîne de résultat
                StringBuilder resultBuilder = new StringBuilder();
                resultBuilder.append("Recettes par ingrédient :\n");
                for (Map.Entry<String, List<Recipe>> entry : recipesByIngredientMap.entrySet()) {
                    String ingredient = entry.getKey();
                    List<Recipe> recipes = entry.getValue();
                    resultBuilder.append(ingredient).append(" :\n");
                    for (Recipe recipe : recipes) {
                        resultBuilder.append("- ").append(recipe.getTitle()).append("\n");
                    }
                }
                result = resultBuilder.toString();
                break;
            case "Recettes regroupées par nombre d'étapes":
                Map<Integer, List<Recipe>> recipesByStepCount = new HashMap<>();
                for (Recipe recipe : recipeRepo.getRecipes()) {
                    int stepCount = recipe.getPreparationSteps().size();
                    List<Recipe> recipes = recipesByStepCount.getOrDefault(stepCount, new ArrayList<>());
                    recipes.add(recipe);
                    recipesByStepCount.put(stepCount, recipes);
                }

                // Construire la change de résultat
                StringBuilder resulteBuilder = new StringBuilder();
                resulteBuilder.append("Recettes regroupées par nombre d'étapes :\n");
                for (Map.Entry<Integer, List<Recipe>> entry : recipesByStepCount.entrySet()) {
                    int stepCount = entry.getKey();
                    List<Recipe> recipes = entry.getValue();
                    resulteBuilder.append("Recettes avec ").append(stepCount).append(" étape(s) :\n");
                    for (Recipe recipe : recipes) {
                        resulteBuilder.append("- ").append(recipe.getTitle()).append("\n");
                    }
                }
                result = resulteBuilder.toString();
                break;


        }

        // Afficher le résultat dans la zone de texte
        resultLabel.setText(result);
    }

    @FXML
    protected void Return(ActionEvent event) {
        try {
            // Fermer la fenêtre parente
            Button button = (Button) event.getSource();
            Stage stage = (Stage) button.getScene().getWindow();
            stage.close();

            // Charger le fichier FXML de la nouvelle page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("recettes.fxml"));
            Scene scene = new Scene(loader.load());

            // Configurer le stage
            Stage newStage = new Stage();
            newStage.setTitle("Recettes");
            newStage.setScene(scene);
            newStage.setResizable(false); // Définir la fenêtre comme non-redimensionnable

            // Afficher le stage
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Afficher une alerte en cas d'erreur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Une erreur s'est produite lors du chargement des recettes.");
            alert.showAndWait();
        }
    }
}