package Presentation;

import Repositories.RecepieRepo;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.util.Duration;
import models.Recipe;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ChoiceController {
    @FXML
    private Button graphicalPresentationButton;

    @FXML
    private Button textualPresentationButton;

    @FXML
    protected void onGraphicalPresentationButtonClick(ActionEvent event) {
        try {
            // Fermer la fenêtre parente
            Button button = (Button) event.getSource();
            Stage stage = (Stage) button.getScene().getWindow();
            stage.close();

            // Charger le fichier FXML de la nouvelle page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("recettes.fxml"));
            Scene scene = new Scene(loader.load());

            // Configurer le stage
            Stage newStage = new Stage();
            newStage.setTitle("Recettes");
            newStage.setResizable(false); // Définir la fenêtre comme non-redimensionnable
            newStage.setScene(scene);

            // Afficher le stage
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Afficher une alerte en cas d'erreur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Une erreur s'est produite lors du chargement des recettes.");
            alert.showAndWait();
        }
    }





    @FXML
    protected void onTextualPresentationButtonClick() {
        // Afficher un message dans la console
        System.out.println("Bienvenue dans la présentation textuelle!");

        // Déclarer une variable pour contrôler la boucle
        boolean continuer = true;

        // Boucle pour maintenir le menu principal
        while (continuer) {
            // Afficher les deux propositions
            System.out.println("1. Découvrez nos recettes");
            System.out.println("2. Quitter");

            System.out.print("Votre choix : ");

            // Lire le choix de l'utilisateur depuis la console
            Scanner scanner = new Scanner(System.in);
            int choix = scanner.nextInt();

            // Vérifier le choix de l'utilisateur
            switch (choix) {
                case 1:
                    // Afficher toutes les fonctionnalités relatives aux recettes
                    afficherFonctionnalitesRecettes();
                    break;
                case 2:
                    // Quitter l'application
                    quitter();
                    // Mettre fin à la boucle
                    continuer = false;
                    break;
                default:
                    System.out.println("Choix invalide.");
                    break;
            }
        }
    }


    // Fonction pour afficher toutes les fonctionnalités relatives aux recettes
    private void afficherFonctionnalitesRecettes() {
        RecepieRepo recipeRepo = new RecepieRepo();
        recipeRepo.init("C:\\Users\\nassim\\ProjetRecettes\\src\\main\\resources\\Presentation\\recipes.xml");

        // Afficher un menu pour permettre au client de choisir
        System.out.println("Menu :");
        System.out.println("1. Toutes les recettes");
        System.out.println("2. Recettes par ingrédient");
        System.out.println("3. Nombre d'œufs par recette");
        System.out.println("4. Recettes fournissant moins de 500 calories");
        System.out.println("5. Liste des titres de recettes");
        System.out.println("6. Recherche de recette par titre");
        System.out.println("7. Total d'œufs utilisés");
        System.out.println("8. Recettes avec de l'huile d'olive");
        System.out.println("9. Recette avec la quantité de sucre pour Zuppa Inglese");
        System.out.println("10. Afficher les deux premières étapes de Zuppa Inglese");
        System.out.println("11. Recettes avec plus de cinq étapes");
        System.out.println("12. Recettes sans beurre");
        System.out.println("13. Recettes avec des ingrédients communs à Zuppa Inglese");
        System.out.println("14. Recette la plus calorique");
        System.out.println("15. Unité d'ingrédient la plus fréquente");
        System.out.println("16. Calculer le nombre d'ingrédients par recette");
        System.out.println("17. Recette avec le plus de gras");
        System.out.println("18. Ingrédient le plus utilisé");
        System.out.println("19. Afficher les recettes triées par nombre d'ingrédients");
        System.out.println("20. Afficher les recettes par étape de préparation");
        System.out.println("21. Trouver la recette la plus simple");

        System.out.print("Votre choix : ");

        // Lire le choix de l'utilisateur depuis la console
        Scanner scanner = new Scanner(System.in);
        int choix = scanner.nextInt();

        switch (choix) {
            case 1:
                afficherToutesLesRecettes(recipeRepo);
                break;
            case 2:
                afficherRecettesParIngredient(recipeRepo);
                break;
            case 3:
                afficherNombreOeufsParRecette(recipeRepo);
                break;
            case 4:
                afficherRecettesMoins500Calories(recipeRepo);
                break;
            case 5:
                afficherListeTitresRecettes(recipeRepo);
                break;
            case 6:
                rechercherRecetteParTitre(recipeRepo, scanner);
                break;
            case 7:
                afficherTotalOeufsUtilises(recipeRepo);
                break;
            case 8:
                afficherRecettesAvecHuileOlive(recipeRepo);
                break;
            case 9:
                afficherQuantiteSucrePourZuppaInglese(recipeRepo);
                break;
            case 10:
                afficherDeuxPremieresEtapesZuppaInglese(recipeRepo);
                break;
            case 11:
                afficherRecettesPlusCinqEtapes(recipeRepo);
                break;
            case 12:
                afficherRecettesSansBeurre(recipeRepo);
                break;
            case 13:
                afficherRecettesAvecIngrCommunsZuppaInglese(recipeRepo);
                break;
            case 14:
                afficherRecettePlusCalorique(recipeRepo);
                break;
            case 15:
                afficherUniteIngredientPlusFreq(recipeRepo);
                break;
            case 16:
                afficherNbIngrParRecette(recipeRepo);
                break;
            case 17:
                afficherRecettePlusGras(recipeRepo);
                break;
            case 18:
                afficherIngredientPlusUtilise(recipeRepo);
                break;
            case 19:
                afficherRecettesTrieesNbIngr(recipeRepo);
                break;
            case 20:
                Map<String, Integer> recipesByPreparationStep = recipeRepo.calculateRecipesByPreparationStep();
                for (Map.Entry<String, Integer> entry : recipesByPreparationStep.entrySet()) {
                    String step = entry.getKey();
                    int recipeCount = entry.getValue();
                    System.out.println(step + " : " + recipeCount + " recettes");
                }
                break;
            case 21:
                afficherRecettePlusSimple(recipeRepo);
                break;
            default:
                System.out.println("Choix invalide.");
                break;
        }
    }
    private void quitter() {
        System.out.println("Au revoir !");
        System.exit(0);
    }

    // Afficher toutes les recettes
    private static void afficherToutesLesRecettes(RecepieRepo recipeRepo) {
        List<Recipe> recettes = recipeRepo.getRecipes();
        for (Recipe recette : recettes) {
            System.out.println(recette.getTitle());
        }
    }

    // Afficher les recettes par ingrédient
    private static void afficherRecettesParIngredient(RecepieRepo recipeRepo) {
        recipeRepo.displayRecipesByIngredient();
    }
    private void afficherNombreOeufsParRecette(RecepieRepo recipeRepo) {
        Map<Recipe, Integer> eggsPerRecipe = recipeRepo.calculateEggsPerRecipe();
        System.out.println("Nombre d'œufs par recette :");
        for (Map.Entry<Recipe, Integer> entry : eggsPerRecipe.entrySet()) {
            Recipe recipe = entry.getKey();
            int eggCount = entry.getValue();
            System.out.println(recipe.getTitle() + " : " + eggCount);
        }
    }
    private void afficherRecettesMoins500Calories(RecepieRepo recipeRepo) {
        List<Recipe> recipesUnder500Calories = recipeRepo.getRecipesUnder500Calories();
        System.out.println("Recettes fournissant moins de 500 calories :");
        for (Recipe recipe : recipesUnder500Calories) {
            System.out.println(recipe.getTitle() + " - " + recipe.getNutrition().getCalories() + " calories");
        }
    }
    private void afficherListeTitresRecettes(RecepieRepo recipeRepo) {
        List<String> recipeTitles = recipeRepo.listRecipeTitles();
        System.out.println("Liste des titres de recettes :");
        for (String title : recipeTitles) {
            System.out.println(title);
        }
    }
    private void rechercherRecetteParTitre(RecepieRepo recipeRepo, Scanner scanner) {
        System.out.print("Entrez le titre de la recette : ");
        String title = scanner.nextLine();
        Recipe foundRecipe = recipeRepo.findRecipeByTitle(title);
        if (foundRecipe != null) {
            System.out.println("Recette trouvée : " + foundRecipe);
        } else {
            System.out.println("Aucune recette trouvée avec ce titre.");
        }
    }
    private void afficherTotalOeufsUtilises(RecepieRepo recipeRepo) {
        int totalEggs = recipeRepo.getTotalEggsUsed();
        System.out.println("Total d'œufs utilisés : " + totalEggs);
    }
    private void afficherRecettesAvecHuileOlive(RecepieRepo recipeRepo) {
        List<Recipe> recipesWithOliveOil = recipeRepo.getRecipesWithOliveOil();
        System.out.println("Recettes avec de l'huile d'olive :");
        for (Recipe recipe : recipesWithOliveOil) {
            System.out.println(recipe.getTitle());
        }
    }
    private void afficherQuantiteSucrePourZuppaInglese(RecepieRepo recipeRepo) {
        double sugarQuantity = recipeRepo.getSugarQuantityForZuppaInglese();
        System.out.println("Quantité de sucre pour Zuppa Inglese : " + sugarQuantity);
    }
    private void afficherDeuxPremieresEtapesZuppaInglese(RecepieRepo recipeRepo) {
        recipeRepo.displayFirstTwoStepsOfZuppaInglese();
    }
    private void afficherRecettesPlusCinqEtapes(RecepieRepo recipeRepo) {
        List<Recipe> recipesWithMoreThanFiveSteps = recipeRepo.getRecipesWithMoreThanFiveSteps();
        System.out.println("Recettes avec plus de cinq étapes :");
        for (Recipe recipe : recipesWithMoreThanFiveSteps) {
            System.out.println(recipe.getTitle());
        }
    }
    private void afficherRecettesSansBeurre(RecepieRepo recipeRepo) {
        List<Recipe> recipesWithoutButter = recipeRepo.getRecipesWithoutButter();
        System.out.println("Recettes sans beurre :");
        for (Recipe recipe : recipesWithoutButter) {
            System.out.println(recipe.getTitle());
        }
    }
    private void afficherRecettesAvecIngrCommunsZuppaInglese(RecepieRepo recipeRepo) {
        List<Recipe> recipesWithCommonIngredients = recipeRepo.getRecipesWithCommonIngredients();
        System.out.println("Recettes avec des ingrédients communs à Zuppa Inglese :");
        for (Recipe recipe : recipesWithCommonIngredients) {
            System.out.println(recipe.getTitle());
        }
    }
    private void afficherRecettePlusCalorique(RecepieRepo recipeRepo) {
        Recipe mostCaloricRecipe = recipeRepo.getMostCaloricRecipe();
        if (mostCaloricRecipe != null) {
            System.out.println("Recette la plus calorique : " + mostCaloricRecipe.getTitle());
        } else {
            System.out.println("Aucune recette trouvée.");
        }
    }
    private void afficherUniteIngredientPlusFreq(RecepieRepo recipeRepo) {
        String mostFrequentUnit = recipeRepo.unitePlusFrequente();
        System.out.println("Unité d'ingrédient la plus fréquente : " + mostFrequentUnit);
    }
    private void afficherNbIngrParRecette(RecepieRepo recipeRepo) {
        Map<Recipe, Integer> ingredientCountPerRecipe = recipeRepo.calculateIngredientCountPerRecipe();
        System.out.println("Nombre d'ingrédients par recette :");
        for (Map.Entry<Recipe, Integer> entry : ingredientCountPerRecipe.entrySet()) {
            Recipe recipe = entry.getKey();
            int ingredientCount = entry.getValue();
            System.out.println(recipe.getTitle() + " : " + ingredientCount);
        }
    }
    private void afficherRecettePlusGras(RecepieRepo recipeRepo) {
        Recipe recipeWithMostFat = recipeRepo.getRecipeWithMostFat();
        if (recipeWithMostFat != null) {
            System.out.println("Recette avec le plus de gras : " + recipeWithMostFat.getTitle());
        } else {
            System.out.println("Aucune recette trouvée.");
        }
    }
    private void afficherIngredientPlusUtilise(RecepieRepo recipeRepo) {
        String mostUsedIngredient = recipeRepo.mostUsedIngredient();
        System.out.println("Ingrédient le plus utilisé : " + mostUsedIngredient);
    }
    private void afficherRecettesTrieesNbIngr(RecepieRepo recipeRepo) {
        List<Recipe> sortedRecipes = recipeRepo.displayRecipesSortedByIngredientCount();
        System.out.println("Recettes triées par nombre d'ingrédients :");
        for (Recipe recipe : sortedRecipes) {
            System.out.println(recipe.getTitle() + " - " + recipe.getIngredients().size() + " ingrédients");
        }
    }
    private void afficherRecettesParEtapePreparation(RecepieRepo recipeRepo) {
        Map<String, Integer> recipesByPreparationStep = recipeRepo.calculateRecipesByPreparationStep();
        System.out.println("Recettes par étape de préparation :");
        for (Map.Entry<String, Integer> entry : recipesByPreparationStep.entrySet()) {
            String step = entry.getKey();
            int count = entry.getValue();
            System.out.println(step + " - " + count + " recettes");
        }
    }
    private void afficherRecettePlusSimple(RecepieRepo recipeRepo) {
        Recipe easiestRecipe = recipeRepo.findEasiestRecipe();
        if (easiestRecipe != null) {
            System.out.println("Recette la plus simple : " + easiestRecipe.getTitle());
        } else {
            System.out.println("Aucune recette trouvée.");
        }
    }


}
