package Presentation;

import Repositories.RecepieRepo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.Recipe;
import models.Ingredient;

import java.io.IOException;
import java.util.List;

public class RecetteController {


    @FXML
    private ListView<String> recettesListView;
    @FXML
    private TextArea texte ;
    @FXML
    private ListView<String> functionListView;
    @FXML
    private TextArea additionalTextArea;

    private RecepieRepo recipesRepo;


    @FXML
    public void initialize() {
        // Initialiser le repository des recettes
        recipesRepo = new RecepieRepo();
        recipesRepo.init("C:\\Users\\nassim\\ProjetRecettes\\src\\main\\resources\\Presentation\\recipes.xml");

        // Récupérer les noms des recettes
        List<String> recipeTitles = recipesRepo.getRecipeTitle();

        // Charger les noms des recettes dans la ListView
        recettesListView.getItems().addAll(recipeTitles);

        // Utiliser une cell factory pour afficher les noms des recettes sous forme de boutons
        recettesListView.setCellFactory(param -> new ListCell<String>() {
            private final Button button = new Button();

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    button.setText(item);
                    button.setOnAction(event -> {
                        // Récupérer le titre de la recette sélectionnée
                        String selectedRecipeTitle = item;

                        // Trouver la recette correspondante dans le repository
                        Recipe selectedRecipe = recipesRepo.findRecipeByTitle(selectedRecipeTitle);

                        if (selectedRecipe != null) {
                            // Afficher toutes les informations sur la recette dans une boîte de dialogue ou une nouvelle vue
                            showRecipeDetails(selectedRecipe);
                        } else {
                            // Afficher une alerte si la recette n'est pas trouvée
                            showAlert("Recette introuvable", "La recette sélectionnée est introuvable.");
                        }
                    });
                    setGraphic(button);
                }
            }
        });

        // Ajouter les fonctions à la ListView


    }

    private void showRecipeDetails(Recipe recipe) {
        // Construire une chaîne de texte avec les détails de la recette
        StringBuilder detailsBuilder = new StringBuilder();
        detailsBuilder.append("Titre: ").append(recipe.getTitle()).append("\n");


        // Récupérer la liste des ingrédients de la recette
        List<Ingredient> ingredients = recipe.getIngredients();
        if (ingredients != null && !ingredients.isEmpty()) {
            detailsBuilder.append("Ingrédients: ");
            for (Ingredient ingredient : ingredients) {
                // Ajouter le nom de l'ingrédient à la chaîne de texte
                detailsBuilder.append(ingredient.getName()).append(", ");
            }
            // Supprimer la virgule supplémentaire à la fin
            detailsBuilder.deleteCharAt(detailsBuilder.length() - 2);
            detailsBuilder.append("\n");
        }

        // Ajouter les étapes de préparation à la chaîne de texte
        detailsBuilder.append("Préparation: \n");
        List<String> preparationSteps = recipe.getPreparationSteps();
        if (preparationSteps != null && !preparationSteps.isEmpty()) {
            for (String step : preparationSteps) {
                detailsBuilder.append("- ").append(step).append("\n");
            }
        }

        // Afficher les détails dans un composant TextArea ou Label sur la même page
        texte.setText(detailsBuilder.toString());
    }

    @FXML
    protected void Return(ActionEvent event) {
        try {
            // Fermer la fenêtre parente
            Button button = (Button) event.getSource();
            Stage stage = (Stage) button.getScene().getWindow();
            stage.close();

            // Charger le fichier FXML de la nouvelle page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Choice.fxml"));
            Scene scene = new Scene(loader.load());

            // Configurer le stage
            Stage newStage = new Stage();
            newStage.setTitle("Recettes");
            newStage.setScene(scene);
            newStage.setResizable(false); // Définir la fenêtre comme non-redimensionnable

            // Afficher le stage
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Afficher une alerte en cas d'erreur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Une erreur s'est produite lors du chargement des recettes.");
            alert.showAndWait();
        }
    }

    @FXML
    protected void toFonctions(ActionEvent event) {
        try {
            // Fermer la fenêtre parente
            Button button = (Button) event.getSource();
            Stage stage = (Stage) button.getScene().getWindow();
            stage.close();

            // Charger le fichier FXML de la nouvelle page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FonctionRecettes.fxml"));
            Scene scene = new Scene(loader.load());

            // Configurer le stage
            Stage newStage = new Stage();
            newStage.setTitle("Recettes");
            newStage.setScene(scene);
            newStage.setResizable(false); // Définir la fenêtre comme non-redimensionnable

            // Afficher le stage
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Afficher une alerte en cas d'erreur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Une erreur s'est produite lors du chargement des recettes.");
            alert.showAndWait();
        }
    }


    @FXML
    protected void onRecipeClicked(ActionEvent event) {
        // Récupérer le titre de la recette sélectionnée
        String selectedRecipeTitle = recettesListView.getSelectionModel().getSelectedItem();

        // Trouver la recette correspondante dans le repository
        Recipe selectedRecipe = recipesRepo.findRecipeByTitle(selectedRecipeTitle);

        if (selectedRecipe != null) {
            // Afficher toutes les informations sur la recette dans une boîte de dialogue ou une nouvelle vue
            showRecipeDetails(selectedRecipe);
        } else {
            // Afficher une alerte si la recette n'est pas trouvée
            showAlert("Recette introuvable", "La recette sélectionnée est introuvable.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
