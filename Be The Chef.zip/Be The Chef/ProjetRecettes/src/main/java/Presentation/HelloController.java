package Presentation;

import Repositories.RecepieRepo;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import models.Recipe;

import java.util.List;

public class HelloController {
    private RecepieRepo recipeRepo = new RecepieRepo();
    private List<Recipe> allRecipes;

    @FXML
    private Label welcomeText;
    @FXML
    private Label AfficherRecettes;
    @FXML
    private Label recettesLabel;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
    @FXML
    protected void onButtonClick() {
        recettesLabel.setText("Welcome to JavaFX Application!");


    }
}
